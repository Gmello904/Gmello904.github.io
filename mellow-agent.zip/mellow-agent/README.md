# Mellow Agent

Describe a business in plain words and Mellow Agent builds an AI agent for it: name, tone, instructions, knowledge, rules and abilities. You can edit everything and test the agent in a live chat.

## Run it in VS Code
1. Install Node.js 20 or newer from nodejs.org.
2. Unzip this folder and open it in VS Code (File > Open Folder).
3. Copy `.env.example` to `.env` and put your Anthropic API key in it (console.anthropic.com).
4. Open the terminal (Ctrl+`) and run:
   ```
   npm install
   npm start
   ```
5. Visit http://localhost:3000

## How it works
- `server.js`: two endpoints. `/api/generate` turns a business description into an agent configuration. `/api/chat` runs a conversation as that agent. Your API key stays on the server.
- `public/index.html`: the whole interface.

## Next steps
1. Save agents in a database (SQLite or Postgres) with company accounts and login.
2. Upload documents (PDF, Word) as the agent's knowledge.
3. Connect real tools: calendar for bookings, a CRM or Google Sheet for leads, email for hand-over.
4. Publish each agent as a website chat widget and a WhatsApp number.
5. Add plans, usage limits and billing.
